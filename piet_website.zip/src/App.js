import Header from "./components/header";
import Footer from "./components/Footer";
import Link from "./components/link";
import Home from "./components/home"
import Sidenav from "./components/sidenav";
import Place from "./components/place"

function App() {
  return (

    <>
      <Sidenav />
      <Link />
      <Header />
      <Home />
      {/* <Place /> */}
      <Footer />
    </>
  );
}

export default App;
