import React from 'react'
import place_1 from '../img/place_1.png'
import place_2 from '../img/place_2.png'
import place_3 from '../img/place_3.png'
import ScrollAnimation from 'react-animate-on-scroll';

export default function home() {
  return (
    <div><div
      id="carouselExampleCrossfade"
      class="carousel slide carousel-fade relative"
      data-bs-ride="carousel"
    >
      <div class="carousel-indicators absolute right-0 bottom-0 left-0 flex justify-center p-0 mb-4">
        <button
          type="button"
          data-bs-target="#carouselExampleCrossfade"
          data-bs-slide-to="0"
          class="active"
          aria-current="true"
          aria-label="Slide 1"
        ></button>
        <button
          type="button"
          data-bs-target="#carouselExampleCrossfade"
          data-bs-slide-to="1"
          aria-label="Slide 2"
        ></button>
        <button
          type="button"
          data-bs-target="#carouselExampleCrossfade"
          data-bs-slide-to="2"
          aria-label="Slide 3"
        ></button>
      </div>
      <div class="carousel-inner relative w-full overflow-hidden">
        <div class="carousel-item active float-left w-full">
          <img
            src="https://www.piet.co.in/wp-content/uploads/2022/09/2-1-1200x405.jpg"
            class="block w-full"
            alt="Wild Landscape"
          />
        </div>
        <div class="carousel-item float-left w-full">
          <img
            src="https://www.piet.co.in/wp-content/uploads/2022/09/Banner-PIET-1200x353.jpg"
            class="block w-full"
            alt="Camera"
          />
        </div>
        <div class="carousel-item float-left w-full">
          <img
            src="https://www.piet.co.in/wp-content/uploads/2022/09/banner-last-2-1200x353.jpg"
            class="block w-full"
            alt="Exotic Fruits"
          />
        </div>
      </div>
      <button
        class="carousel-control-prev absolute top-0 bottom-0 flex items-center justify-center p-0 text-center border-0 hover:outline-none hover:no-underline focus:outline-none focus:no-underline left-0"
        type="button"
        data-bs-target="#carouselExampleCrossfade"
        data-bs-slide="prev"
      >
        <span class="carousel-control-prev-icon inline-block bg-no-repeat" aria-hidden="true"></span>
        <span class="visually-hidden">Previous</span>
      </button>
      <button
        class="carousel-control-next absolute top-0 bottom-0 flex items-center justify-center p-0 text-center border-0 hover:outline-none hover:no-underline focus:outline-none focus:no-underline right-0"
        type="button"
        data-bs-target="#carouselExampleCrossfade"
        data-bs-slide="next"
      >
        <span class="carousel-control-next-icon inline-block bg-no-repeat" aria-hidden="true"></span>
        <span class="visually-hidden">Next</span>
      </button>
    </div>

    {/* About */}

    <div class="grid grid-cols-6 gap-4">
  <div class="col-start-1 col-end-3 ...">
    <h1 className='bg-red-700 h-20 text-center font-bold pt-4 text-slate-200 '>YOUR CAREER BEGINS WITH US</h1>
  </div>
  <div class="col-end-7 col-span-4 ...">
    
  </div>
</div>


  
    {/* Campu Placment */}

      <div className="mt-4 bg-red-500 text-center font-bold pb-5" >
        <ScrollAnimation animateIn="animate__animated animate__slideInLeft" className='my-element'>
          <h1 className='text-2xl p-3' >Campus Placement</h1>
        </ScrollAnimation>
        <div
          id="carouselDarkVariant"
          class="carousel slide carousel-fade carousel-dark relative"
          data-bs-ride="carousel"
        >
          <div class=" absolute right-0 bottom-0 left-0 flex justify-center p-0 mb-4">
            <button
              data-bs-target="#carouselDarkVariant"
              data-bs-slide-to="0"
              class="active"
              aria-current="true"
              aria-label="Slide 1"
            ></button>
            <button
              data-bs-target="#carouselDarkVariant"
              data-bs-slide-to="1"
              aria-label="Slide 1"
            ></button>
            <button
              data-bs-target="#carouselDarkVariant"
              data-bs-slide-to="2"
              aria-label="Slide 1"
            ></button>
          </div>


          <div class="carousel-inner relative w-full overflow-hidden mt-4">

            <div class="carousel-item active relative float-left w-full ">
              <img
                src={place_1}
                class="block w-full"
                alt="Motorbike Smoke"

              />

            </div>

            <div class="carousel-item relative float-left w-full">
              <img
                src={place_2}
                class="block w-full"
                alt="Mountaintop"
              />

            </div>
            <div class="carousel-item relative float-left w-full">
              <img
                src={place_3}
                class="block w-full"
                alt="Woman Reading a Book"
              />

            </div>
          </div>
          <button
            class="carousel-control-prev absolute top-0  bottom-0 flex items-center justify-center p-0 text-center border-0 hover:outline-none hover:no-underline focus:outline-none focus:no-underline left-0"
            type="button"
            data-bs-target="#carouselDarkVariant"
            data-bs-slide="prev"
          >
            <span class="carousel-control-prev-icon inline-block bg-no-repeat mr-12" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
          </button>
          <button
            class="carousel-control-next absolute top-0 bottom-0 flex items-center justify-center p-0 text-center border-0 hover:outline-none hover:no-underline focus:outline-none focus:no-underline right-0"
            type="button"
            data-bs-target="#carouselDarkVariant"
            data-bs-slide="next"
          >
            <span class="carousel-control-next-icon inline-block bg-no-repeat ml-12" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
          </button>
        </div>
      </div>

    </div>
  )
}
