import React, { Component } from 'react';

class sidenav extends Component {
    render() {
        return (
            <section >
                <div className="head-bg">
                    <marquee direction="left" id='scroll_news'>
                        <div onMouseOver={() => { document.getElementById('scroll_news').stop() }} onMouseOut={() => { document.getElementById('scroll_news').start() }}>
                            If Satisfied tell other if Not Tell Us-<strong> Contact us </strong>
                        </div>
                    </marquee>
                </div>
            </section>
        )
    }
}

export default sidenav